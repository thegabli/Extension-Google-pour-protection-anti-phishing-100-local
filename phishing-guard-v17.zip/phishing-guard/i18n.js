/**
 * PhishingGuard — i18n.js
 * Traductions : Français (fr), English (en), Español (es)
 * Chargé en premier dans manifest.json
 */
const PG_TRANSLATIONS = {
  fr: {
    // Header popup
    hdr_sub:        "Protection anti-phishing",

    // Bannière — états
    state_safe:     "Email connu et sur",
    state_unknown:  "Email inconnu",
    state_phishing: "Phishing detecte",

    // Bannière — raisons prédéfinies
    reason_whitelist: "Dans votre liste de confiance",
    reason_blacklist: "Bloque manuellement dans votre blacklist",

    // Bannière — DKIM / SPF
    auth_checking:   "Verification DKIM / SPF...",
    auth_ok:         "DKIM / SPF : expediteur authentifie",
    auth_warn:       "Expediteur douteux - anomalie DKIM / SPF",
    auth_unavailable:"DKIM / SPF : donnees non disponibles",

    // Bannière — boutons
    btn_add_trust:  "Ajouter a ma liste de confiance",
    btn_added:      "Ajoute a votre liste",

    // Toast
    toast_added:    "ajoute a votre liste",

    // Popup — onglets
    tab_analyze:    "Analyser",
    tab_whitelist:  "Confiance",
    tab_blacklist:  "Blacklist",
    tab_settings:   "Parametres",

    // Popup — Analyser
    lbl_analyze:    "Analyser un email manuellement",
    placeholder_analyze: "ex: support@paypal.com",
    btn_go:         "Go",
    verdict_phishing: "PHISHING DETECTE",
    verdict_safe:     "EMAIL LEGITIME",
    reason_trusted:   "Dans votre liste de confiance personnelle",
    reason_safe:      "Domaine reconnu et sur",

    // Popup — Confiance
    lbl_whitelist_add:  "Ajouter un domaine ou email de confiance",
    lbl_whitelist_list: "Domaines enregistres",
    placeholder_wl:     "ex: monami@gmail.com ou domaine.fr",
    btn_add:            "Ajouter",
    wl_empty:           "Aucun domaine ajoute pour l'instant.",

    // Popup — Blacklist
    lbl_blacklist_add:  "Ajouter un domaine ou email phishing",
    lbl_blacklist_list: "Domaines bloques manuellement",
    placeholder_bl:     "ex: arnaque@faux-paypal.com ou faux-paypal.com",
    btn_block:          "Bloquer",
    bl_empty:           "Aucun domaine bloque manuellement.",

    // Popup — Parametres
    lbl_language:    "Langue / Language / Idioma",
    footer:          "PhishingGuard v3.1 - 100% local, aucune donnee envoyee"
  },

  en: {
    hdr_sub:        "Anti-phishing protection",

    state_safe:     "Safe email",
    state_unknown:  "Unknown sender",
    state_phishing: "Phishing detected",

    reason_whitelist: "In your trusted list",
    reason_blacklist: "Manually blocked in your blacklist",

    auth_checking:   "Checking DKIM / SPF...",
    auth_ok:         "DKIM / SPF: sender authenticated",
    auth_warn:       "Suspicious sender - DKIM / SPF anomaly",
    auth_unavailable:"DKIM / SPF: data unavailable",

    btn_add_trust:  "Add to trusted list",
    btn_added:      "Added to your list",

    toast_added:    "added to your list",

    tab_analyze:    "Analyze",
    tab_whitelist:  "Trusted",
    tab_blacklist:  "Blacklist",
    tab_settings:   "Settings",

    lbl_analyze:    "Analyze an email manually",
    placeholder_analyze: "e.g. support@paypal.com",
    btn_go:         "Go",
    verdict_phishing: "PHISHING DETECTED",
    verdict_safe:     "LEGITIMATE EMAIL",
    reason_trusted:   "In your personal trusted list",
    reason_safe:      "Recognized and safe domain",

    lbl_whitelist_add:  "Add a trusted domain or email",
    lbl_whitelist_list: "Saved domains",
    placeholder_wl:     "e.g. friend@gmail.com or domain.com",
    btn_add:            "Add",
    wl_empty:           "No domain added yet.",

    lbl_blacklist_add:  "Add a phishing domain or email",
    lbl_blacklist_list: "Manually blocked domains",
    placeholder_bl:     "e.g. scam@fake-paypal.com or fake-paypal.com",
    btn_block:          "Block",
    bl_empty:           "No domain blocked manually.",

    lbl_language:    "Langue / Language / Idioma",
    footer:          "PhishingGuard v3.1 - 100% local, no data sent"
  },

  es: {
    hdr_sub:        "Proteccion anti-phishing",

    state_safe:     "Correo seguro",
    state_unknown:  "Remitente desconocido",
    state_phishing: "Phishing detectado",

    reason_whitelist: "En su lista de confianza",
    reason_blacklist: "Bloqueado manualmente en su lista negra",

    auth_checking:   "Verificando DKIM / SPF...",
    auth_ok:         "DKIM / SPF: remitente autenticado",
    auth_warn:       "Remitente sospechoso - anomalia DKIM / SPF",
    auth_unavailable:"DKIM / SPF: datos no disponibles",

    btn_add_trust:  "Agregar a lista de confianza",
    btn_added:      "Agregado a su lista",

    toast_added:    "agregado a su lista",

    tab_analyze:    "Analizar",
    tab_whitelist:  "Confianza",
    tab_blacklist:  "Lista negra",
    tab_settings:   "Ajustes",

    lbl_analyze:    "Analizar un correo manualmente",
    placeholder_analyze: "ej: soporte@paypal.com",
    btn_go:         "Ir",
    verdict_phishing: "PHISHING DETECTADO",
    verdict_safe:     "CORREO LEGITIMO",
    reason_trusted:   "En su lista de confianza personal",
    reason_safe:      "Dominio reconocido y seguro",

    lbl_whitelist_add:  "Agregar un dominio o correo de confianza",
    lbl_whitelist_list: "Dominios guardados",
    placeholder_wl:     "ej: amigo@gmail.com o dominio.com",
    btn_add:            "Agregar",
    wl_empty:           "Ningun dominio agregado aun.",

    lbl_blacklist_add:  "Agregar un dominio o correo de phishing",
    lbl_blacklist_list: "Dominios bloqueados manualmente",
    placeholder_bl:     "ej: estafa@falso-paypal.com o falso-paypal.com",
    btn_block:          "Bloquear",
    bl_empty:           "Ningun dominio bloqueado manualmente.",

    lbl_language:    "Langue / Language / Idioma",
    footer:          "PhishingGuard v3.1 - 100% local, ningun dato enviado"
  }
};

/**
 * Retourne les traductions pour une langue donnée.
 * Fallback sur le français si la langue est inconnue.
 */
function pgT(lang) {
  return PG_TRANSLATIONS[lang] || PG_TRANSLATIONS["fr"];
}
