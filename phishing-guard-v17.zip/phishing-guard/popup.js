/**
 * PhishingGuard — popup.js
 */
document.addEventListener("DOMContentLoaded", () => {

  const DET = new PhishingDetector();
  let currentLang = "fr";

  // ── Chargement initial ────────────────────────────────────────
  chrome.storage.local.get(["pgLang"], d => {
    currentLang = d.pgLang || "fr";
    document.getElementById("langSelect").value = currentLang;
    applyAll(currentLang);
  });

  // ── applyAll : traduit ET rerend les listes avec la bonne langue
  function applyAll(lang) {
    currentLang = lang;
    const T = pgT(lang);

    // Header
    document.getElementById("hdr-sub").textContent           = T.hdr_sub;

    // Onglets
    document.getElementById("tab-btn-analyze").textContent   = T.tab_analyze;
    document.getElementById("tab-btn-whitelist").textContent = T.tab_whitelist;
    document.getElementById("tab-btn-blacklist").textContent = T.tab_blacklist;
    document.getElementById("tab-btn-settings").textContent  = T.tab_settings;

    // Panneau Analyser
    document.getElementById("lbl-analyze").textContent       = T.lbl_analyze;
    document.getElementById("emailInput").placeholder        = T.placeholder_analyze;
    document.getElementById("analyzeBtn").textContent        = T.btn_go;

    // Panneau Whitelist
    document.getElementById("lbl-wl-add").textContent        = T.lbl_whitelist_add;
    document.getElementById("wlInput").placeholder           = T.placeholder_wl;
    document.getElementById("wlAddBtn").textContent          = T.btn_add;
    document.getElementById("lbl-wl-list").textContent       = T.lbl_whitelist_list;

    // Panneau Blacklist
    document.getElementById("lbl-bl-add").textContent        = T.lbl_blacklist_add;
    document.getElementById("blInput").placeholder           = T.placeholder_bl;
    document.getElementById("blAddBtn").textContent          = T.btn_block;
    document.getElementById("lbl-bl-list").textContent       = T.lbl_blacklist_list;

    // Paramètres
    document.getElementById("lbl-language").textContent      = T.lbl_language;

    // Footer
    document.getElementById("pg-footer").textContent         = T.footer;

    // Rerendre les listes dynamiques avec la nouvelle langue
    renderWhitelist(T);
    renderBlacklist(T);
  }

  // ── Onglets ───────────────────────────────────────────────────
  document.querySelectorAll(".tab").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
    });
  });

  // ── Analyser ──────────────────────────────────────────────────
  document.getElementById("analyzeBtn").addEventListener("click", analyze);
  document.getElementById("emailInput").addEventListener("keydown", e => {
    if (e.key === "Enter") analyze();
  });

  function analyze() {
    const T     = pgT(currentLang);
    const email = document.getElementById("emailInput").value.trim();
    if (!email) return;

    chrome.storage.local.get(["pgWhitelist", "pgBlacklist"], d => {
      const wl     = new Set(d.pgWhitelist || []);
      const bl     = new Set(d.pgBlacklist || []);
      const domain = email.includes("@") ? email.split("@").pop().toLowerCase() : email.toLowerCase();

      const isBlocked = bl.has(domain) || bl.has(email.toLowerCase());
      const isTrusted = wl.has(domain) || wl.has(email.toLowerCase());

      let res, isBad;
      if (isBlocked) {
        isBad = true;
        res   = { isPhishing: true, reasons: [T.reason_blacklist] };
      } else if (isTrusted) {
        isBad = false;
        res   = { isPhishing: false, reasons: [T.reason_trusted] };
      } else {
        res   = DET.analyze(email, []);
        isBad = res.isPhishing;
      }

      const color = isBad ? "#ef4444" : "#22c55e";
      const label = isBad ? T.verdict_phishing : T.verdict_safe;
      const bg    = isBad ? "#1f0000" : "#052e16";

      const head = document.getElementById("resultHead");
      head.style.borderColor = color;
      head.style.background  = bg;

      const v = document.getElementById("resultVerdict");
      v.textContent = label;
      v.style.color = color;

      document.getElementById("resultEmail").textContent = email;

      const ul = document.getElementById("resultReasons");
      if (res.reasons && res.reasons.length) {
        ul.innerHTML = res.reasons.map(r =>
          `<li style="${isBad ? "" : "color:#4ade80"}">&#9888; ${r}</li>`
        ).join("");
      } else {
        ul.innerHTML = `<li style="color:#4ade80">&#10003; ${T.reason_safe}</li>`;
      }

      document.getElementById("result").classList.add("show");
    });
  }

  // ── Whitelist ─────────────────────────────────────────────────
  document.getElementById("wlAddBtn").addEventListener("click", addWlEntry);
  document.getElementById("wlInput").addEventListener("keydown", e => {
    if (e.key === "Enter") addWlEntry();
  });

  function addWlEntry() {
    const val = document.getElementById("wlInput").value.trim().toLowerCase();
    if (!val) return;
    const entry = val.includes("@") ? val.split("@").pop() : val;
    if (!entry) return;
    chrome.storage.local.get("pgWhitelist", d => {
      const wl = new Set(d.pgWhitelist || []);
      wl.add(entry);
      chrome.storage.local.set({ pgWhitelist: [...wl] }, () => {
        document.getElementById("wlInput").value = "";
        renderWhitelist(pgT(currentLang));
      });
    });
  }

  function removeWlEntry(entry) {
    chrome.storage.local.get("pgWhitelist", d => {
      const wl = new Set(d.pgWhitelist || []);
      wl.delete(entry);
      chrome.storage.local.set({ pgWhitelist: [...wl] }, () => renderWhitelist(pgT(currentLang)));
    });
  }

  // T est passé directement pour éviter tout problème de timing avec currentLang
  function renderWhitelist(T) {
    chrome.storage.local.get("pgWhitelist", d => {
      const wl   = d.pgWhitelist || [];
      const cont = document.getElementById("wlList");
      if (!wl.length) {
        cont.innerHTML = `<div class="wl-empty">${T.wl_empty}</div>`;
        return;
      }
      cont.innerHTML = `<div class="wl-list">${
        wl.map(entry => `
          <div class="wl-item">
            <span class="wl-item-icon">&#10003;</span>
            <span class="wl-item-domain">${entry}</span>
            <button class="wl-item-del" data-entry="${entry}">&#10005;</button>
          </div>`
        ).join("")
      }</div>`;
      cont.querySelectorAll(".wl-item-del").forEach(btn => {
        btn.addEventListener("click", () => removeWlEntry(btn.dataset.entry));
      });
    });
  }

  // ── Blacklist ─────────────────────────────────────────────────
  document.getElementById("blAddBtn").addEventListener("click", addBlEntry);
  document.getElementById("blInput").addEventListener("keydown", e => {
    if (e.key === "Enter") addBlEntry();
  });

  function addBlEntry() {
    const val = document.getElementById("blInput").value.trim().toLowerCase();
    if (!val) return;
    const entry = val.includes("@") ? val.split("@").pop() : val;
    if (!entry) return;
    chrome.storage.local.get("pgBlacklist", d => {
      const bl = new Set(d.pgBlacklist || []);
      bl.add(entry);
      chrome.storage.local.set({ pgBlacklist: [...bl] }, () => {
        document.getElementById("blInput").value = "";
        renderBlacklist(pgT(currentLang));
      });
    });
  }

  function removeBlEntry(entry) {
    chrome.storage.local.get("pgBlacklist", d => {
      const bl = new Set(d.pgBlacklist || []);
      bl.delete(entry);
      chrome.storage.local.set({ pgBlacklist: [...bl] }, () => renderBlacklist(pgT(currentLang)));
    });
  }

  function renderBlacklist(T) {
    chrome.storage.local.get("pgBlacklist", d => {
      const bl   = d.pgBlacklist || [];
      const cont = document.getElementById("blList");
      if (!bl.length) {
        cont.innerHTML = `<div class="wl-empty">${T.bl_empty}</div>`;
        return;
      }
      cont.innerHTML = `<div class="wl-list">${
        bl.map(entry => `
          <div class="wl-item">
            <span class="wl-item-icon">&#9940;</span>
            <span class="bl-item-domain">${entry}</span>
            <button class="wl-item-del" data-entry="${entry}">&#10005;</button>
          </div>`
        ).join("")
      }</div>`;
      cont.querySelectorAll(".wl-item-del").forEach(btn => {
        btn.addEventListener("click", () => removeBlEntry(btn.dataset.entry));
      });
    });
  }

  // ── Paramètres — langue ───────────────────────────────────────
  document.getElementById("langSelect").addEventListener("change", e => {
    const newLang = e.target.value;
    chrome.storage.local.set({ pgLang: newLang }, () => applyAll(newLang));
  });

});
