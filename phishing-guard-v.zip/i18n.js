/**
 * PhishingGuard — i18n.js
 * Système de traduction multilingue (FR / EN / ES / DE)
 */
const PG_I18N = {
  fr: {
    tagline: "Protection anti-phishing",
    tab_analyze: "🔍 Analyser",
    tab_whitelist: "✅ Ma liste",
    label_analyze: "Analyser un email manuellement",
    placeholder_email: "ex: support@paypal.com",
    btn_go: "▶ Go",
    label_add_trusted: "Ajouter un domaine ou email de confiance",
    placeholder_wl: "ex: monami@gmail.com ou domaine.fr",
    btn_add: "＋ Ajouter",
    label_registered: "Domaines enregistrés",
    wl_empty: "Aucun domaine ajouté pour l'instant.<br>Ajoutez l'email ou le domaine d'un contact de confiance.",
    footer: "PhishingGuard v4.0 — 100% local, aucune donnée envoyée",
    verdict_phishing: "🚨 PHISHING DÉTECTÉ",
    verdict_safe: "✅ EMAIL LÉGITIME",
    reason_trusted_personal: "✅ Dans votre liste de confiance personnelle",
    reason_known_safe: "✅ Domaine reconnu et sûr",
    reason_db: "Référencé dans notre base phishing",
    reason_trusted_db: "Domaine répertorié comme fiable",
    reason_trusted_user: "Dans votre liste de confiance",
    reason_unknown: "Domaine non répertorié dans notre base",
    reason_subdomain_spoof: 'Usurpation de sous-domaine : "{brand}" dans un domaine non fiable',
    reason_subdomain_classic: "Technique classique de phishing par sous-domaine",
    reason_brand_imitation: 'Imitation probable de "{brand}"',
    reason_suspicious_keyword: 'Mot-clé suspect : "{kw}"',
    reason_suspicious_tld: "Extension de domaine suspecte : .{tld}",
    reason_many_dashes: "Domaine avec plusieurs tirets",
    reason_digits: "Chiffres suspects dans le domaine",
    // Bannière (scanner.js)
    banner_state_safe: "Email connu et sûr",
    banner_state_unknown: "Email inconnu",
    banner_state_phishing: "Phishing détecté",
    banner_close: "Fermer",
    banner_btn_add: "＋ Ajouter à ma liste de confiance",
    banner_btn_done: "Ajouté à votre liste ✓",
    banner_toast_added: '✅ "{domain}" ajouté à votre liste',
    auth_checking: "⟳ Vérification DKIM / SPF…",
    auth_unavailable: "DKIM / SPF : données non disponibles",
    auth_bad: "⚠ Expéditeur douteux — anomalie DKIM / SPF",
    auth_ok: "✓ DKIM / SPF : expéditeur authentifié",
    auth_spf_bad: 'SPF suspect : envoyé via "{mb}" (expéditeur : {sender})',
    auth_dkim_bad: 'DKIM suspect : signé par "{sb}" (expéditeur : {sender})',
    auth_via_bad: 'Relayé via "{via}" — domaine tiers détecté',
    banner_btn_links: "🔗 Analyser les liens ({n})",
    banner_btn_links_none: "🔗 Aucun lien dans cet email",
    links_title: "Analyse des liens",
    links_back: "← Retour",
    link_safe: "Sûr",
    link_unknown: "Inconnu",
    link_dangerous: "Dangereux",
    link_reason_shortener: "Raccourcisseur d'URL ({host}) — destination masquée",
    link_reason_ip: "URL en adresse IP brute — très suspect",
    link_reason_punycode: "Caractères Unicode trompeurs (punycode)",
    link_reason_suspicious_tld: "Extension de domaine suspecte : .{tld}",
    link_reason_brand_in_subdomain: 'Marque "{brand}" dans un sous-domaine non officiel',
    link_reason_text_mismatch: 'Le texte affiche "{text}" mais le lien va vers "{host}"',
    link_reason_many_dashes: "Domaine avec plusieurs tirets",
    link_reason_credentials: "Identifiants intégrés dans l'URL (@)",
    link_reason_ok: "Aucune anomalie détectée",
  },
  en: {
    tagline: "Anti-phishing protection",
    tab_analyze: "🔍 Analyze",
    tab_whitelist: "✅ My list",
    label_analyze: "Analyze an email manually",
    placeholder_email: "e.g. support@paypal.com",
    btn_go: "▶ Go",
    label_add_trusted: "Add a trusted domain or email",
    placeholder_wl: "e.g. friend@gmail.com or domain.com",
    btn_add: "＋ Add",
    label_registered: "Saved domains",
    wl_empty: "No domain added yet.<br>Add the email or domain of a trusted contact.",
    footer: "PhishingGuard v4.0 — 100% local, no data sent",
    verdict_phishing: "🚨 PHISHING DETECTED",
    verdict_safe: "✅ LEGITIMATE EMAIL",
    reason_trusted_personal: "✅ In your personal trusted list",
    reason_known_safe: "✅ Recognized and safe domain",
    reason_db: "Listed in our phishing database",
    reason_trusted_db: "Domain listed as trusted",
    reason_trusted_user: "In your trusted list",
    reason_unknown: "Domain not listed in our database",
    reason_subdomain_spoof: 'Subdomain spoofing: "{brand}" inside an untrusted domain',
    reason_subdomain_classic: "Classic subdomain phishing technique",
    reason_brand_imitation: 'Likely imitation of "{brand}"',
    reason_suspicious_keyword: 'Suspicious keyword: "{kw}"',
    reason_suspicious_tld: "Suspicious TLD: .{tld}",
    reason_many_dashes: "Domain with multiple dashes",
    reason_digits: "Suspicious digits in the domain",
    banner_state_safe: "Known and safe email",
    banner_state_unknown: "Unknown email",
    banner_state_phishing: "Phishing detected",
    banner_close: "Close",
    banner_btn_add: "＋ Add to my trusted list",
    banner_btn_done: "Added to your list ✓",
    banner_toast_added: '✅ "{domain}" added to your list',
    auth_checking: "⟳ Checking DKIM / SPF…",
    auth_unavailable: "DKIM / SPF: data not available",
    auth_bad: "⚠ Suspicious sender — DKIM / SPF anomaly",
    auth_ok: "✓ DKIM / SPF: sender authenticated",
    auth_spf_bad: 'Suspicious SPF: sent via "{mb}" (sender: {sender})',
    auth_dkim_bad: 'Suspicious DKIM: signed by "{sb}" (sender: {sender})',
    auth_via_bad: 'Relayed via "{via}" — third-party domain detected',
    banner_btn_links: "🔗 Scan links ({n})",
    banner_btn_links_none: "🔗 No links in this email",
    links_title: "Link analysis",
    links_back: "← Back",
    link_safe: "Safe",
    link_unknown: "Unknown",
    link_dangerous: "Dangerous",
    link_reason_shortener: "URL shortener ({host}) — destination hidden",
    link_reason_ip: "Raw IP address URL — highly suspicious",
    link_reason_punycode: "Misleading Unicode characters (punycode)",
    link_reason_suspicious_tld: "Suspicious TLD: .{tld}",
    link_reason_brand_in_subdomain: 'Brand "{brand}" used in unofficial subdomain',
    link_reason_text_mismatch: 'Text shows "{text}" but link goes to "{host}"',
    link_reason_many_dashes: "Domain with multiple dashes",
    link_reason_credentials: "Credentials embedded in URL (@)",
    link_reason_ok: "No anomaly detected",
  },
  es: {
    tagline: "Protección anti-phishing",
    tab_analyze: "🔍 Analizar",
    tab_whitelist: "✅ Mi lista",
    label_analyze: "Analizar un correo manualmente",
    placeholder_email: "ej: support@paypal.com",
    btn_go: "▶ Ir",
    label_add_trusted: "Añadir un dominio o correo de confianza",
    placeholder_wl: "ej: amigo@gmail.com o dominio.es",
    btn_add: "＋ Añadir",
    label_registered: "Dominios guardados",
    wl_empty: "Aún no hay dominios añadidos.<br>Añade el correo o dominio de un contacto de confianza.",
    footer: "PhishingGuard v4.0 — 100% local, sin envío de datos",
    verdict_phishing: "🚨 PHISHING DETECTADO",
    verdict_safe: "✅ CORREO LEGÍTIMO",
    reason_trusted_personal: "✅ En tu lista personal de confianza",
    reason_known_safe: "✅ Dominio reconocido y seguro",
    reason_db: "Listado en nuestra base de phishing",
    reason_trusted_db: "Dominio listado como confiable",
    reason_trusted_user: "En tu lista de confianza",
    reason_unknown: "Dominio no listado en nuestra base",
    reason_subdomain_spoof: 'Suplantación de subdominio: "{brand}" en un dominio no confiable',
    reason_subdomain_classic: "Técnica clásica de phishing por subdominio",
    reason_brand_imitation: 'Probable imitación de "{brand}"',
    reason_suspicious_keyword: 'Palabra clave sospechosa: "{kw}"',
    reason_suspicious_tld: "TLD sospechoso: .{tld}",
    reason_many_dashes: "Dominio con varios guiones",
    reason_digits: "Cifras sospechosas en el dominio",
    banner_state_safe: "Correo conocido y seguro",
    banner_state_unknown: "Correo desconocido",
    banner_state_phishing: "Phishing detectado",
    banner_close: "Cerrar",
    banner_btn_add: "＋ Añadir a mi lista de confianza",
    banner_btn_done: "Añadido a tu lista ✓",
    banner_toast_added: '✅ "{domain}" añadido a tu lista',
    auth_checking: "⟳ Verificando DKIM / SPF…",
    auth_unavailable: "DKIM / SPF: datos no disponibles",
    auth_bad: "⚠ Remitente dudoso — anomalía DKIM / SPF",
    auth_ok: "✓ DKIM / SPF: remitente autenticado",
    auth_spf_bad: 'SPF sospechoso: enviado vía "{mb}" (remitente: {sender})',
    auth_dkim_bad: 'DKIM sospechoso: firmado por "{sb}" (remitente: {sender})',
    auth_via_bad: 'Reenviado vía "{via}" — dominio de terceros detectado',
    banner_btn_links: "🔗 Analizar enlaces ({n})",
    banner_btn_links_none: "🔗 Ningún enlace en este correo",
    links_title: "Análisis de enlaces",
    links_back: "← Volver",
    link_safe: "Seguro",
    link_unknown: "Desconocido",
    link_dangerous: "Peligroso",
    link_reason_shortener: "Acortador de URL ({host}) — destino oculto",
    link_reason_ip: "URL con dirección IP — muy sospechoso",
    link_reason_punycode: "Caracteres Unicode engañosos (punycode)",
    link_reason_suspicious_tld: "TLD sospechoso: .{tld}",
    link_reason_brand_in_subdomain: 'Marca "{brand}" en subdominio no oficial',
    link_reason_text_mismatch: 'El texto muestra "{text}" pero el enlace va a "{host}"',
    link_reason_many_dashes: "Dominio con varios guiones",
    link_reason_credentials: "Credenciales en la URL (@)",
    link_reason_ok: "Sin anomalías detectadas",
  },
  de: {
    tagline: "Phishing-Schutz",
    tab_analyze: "🔍 Prüfen",
    tab_whitelist: "✅ Meine Liste",
    label_analyze: "E-Mail manuell prüfen",
    placeholder_email: "z. B. support@paypal.com",
    btn_go: "▶ Los",
    label_add_trusted: "Vertrauenswürdige Domain oder E-Mail hinzufügen",
    placeholder_wl: "z. B. freund@gmail.com oder domain.de",
    btn_add: "＋ Hinzufügen",
    label_registered: "Gespeicherte Domains",
    wl_empty: "Noch keine Domain hinzugefügt.<br>Fügen Sie die E-Mail oder Domain eines vertrauten Kontakts hinzu.",
    footer: "PhishingGuard v4.0 — 100% lokal, keine Daten gesendet",
    verdict_phishing: "🚨 PHISHING ERKANNT",
    verdict_safe: "✅ LEGITIME E-MAIL",
    reason_trusted_personal: "✅ In Ihrer persönlichen Vertrauensliste",
    reason_known_safe: "✅ Bekannte und sichere Domain",
    reason_db: "In unserer Phishing-Datenbank gelistet",
    reason_trusted_db: "Domain als vertrauenswürdig gelistet",
    reason_trusted_user: "In Ihrer Vertrauensliste",
    reason_unknown: "Domain nicht in unserer Datenbank gelistet",
    reason_subdomain_spoof: 'Subdomain-Spoofing: "{brand}" in einer nicht vertrauenswürdigen Domain',
    reason_subdomain_classic: "Klassische Subdomain-Phishing-Technik",
    reason_brand_imitation: 'Wahrscheinliche Nachahmung von "{brand}"',
    reason_suspicious_keyword: 'Verdächtiges Schlüsselwort: "{kw}"',
    reason_suspicious_tld: "Verdächtige TLD: .{tld}",
    reason_many_dashes: "Domain mit mehreren Bindestrichen",
    reason_digits: "Verdächtige Ziffern in der Domain",
    banner_state_safe: "Bekannte und sichere E-Mail",
    banner_state_unknown: "Unbekannte E-Mail",
    banner_state_phishing: "Phishing erkannt",
    banner_close: "Schließen",
    banner_btn_add: "＋ Zu meiner Vertrauensliste hinzufügen",
    banner_btn_done: "Zur Liste hinzugefügt ✓",
    banner_toast_added: '✅ "{domain}" zur Liste hinzugefügt',
    auth_checking: "⟳ DKIM / SPF wird geprüft…",
    auth_unavailable: "DKIM / SPF: Daten nicht verfügbar",
    auth_bad: "⚠ Verdächtiger Absender — DKIM / SPF-Anomalie",
    auth_ok: "✓ DKIM / SPF: Absender authentifiziert",
    auth_spf_bad: 'Verdächtiges SPF: gesendet über "{mb}" (Absender: {sender})',
    auth_dkim_bad: 'Verdächtiges DKIM: signiert von "{sb}" (Absender: {sender})',
    auth_via_bad: 'Weitergeleitet über "{via}" — Drittanbieter-Domain erkannt',
    banner_btn_links: "🔗 Links prüfen ({n})",
    banner_btn_links_none: "🔗 Keine Links in dieser E-Mail",
    links_title: "Link-Analyse",
    links_back: "← Zurück",
    link_safe: "Sicher",
    link_unknown: "Unbekannt",
    link_dangerous: "Gefährlich",
    link_reason_shortener: "URL-Kürzer ({host}) — Ziel verborgen",
    link_reason_ip: "Rohe IP-Adresse — sehr verdächtig",
    link_reason_punycode: "Irreführende Unicode-Zeichen (Punycode)",
    link_reason_suspicious_tld: "Verdächtige TLD: .{tld}",
    link_reason_brand_in_subdomain: 'Marke "{brand}" in inoffizieller Subdomain',
    link_reason_text_mismatch: 'Text zeigt "{text}" aber Link führt zu "{host}"',
    link_reason_many_dashes: "Domain mit mehreren Bindestrichen",
    link_reason_credentials: "Anmeldedaten in URL (@)",
    link_reason_ok: "Keine Auffälligkeit",
  },
};

let PG_LANG = "fr";

function pgT(key, params) {
  const dict = PG_I18N[PG_LANG] || PG_I18N.fr;
  let s = dict[key] || PG_I18N.fr[key] || key;
  if (params) for (const k in params) s = s.replaceAll("{" + k + "}", params[k]);
  return s;
}

/**
 * Traduit une raison française renvoyée par detector.js
 * (compatibilité avec l'ancien format string).
 */
function pgTranslateReason(fr) {
  if (!fr) return "";
  let m;
  if (fr === "Référencé dans notre base phishing") return pgT("reason_db");
  if (fr === "Domaine répertorié comme fiable") return pgT("reason_trusted_db");
  if (fr === "Dans votre liste de confiance") return pgT("reason_trusted_user");
  if (fr === "Domaine non répertorié dans notre base") return pgT("reason_unknown");
  if (fr === "Technique classique de phishing par sous-domaine") return pgT("reason_subdomain_classic");
  if (fr === "Domaine avec plusieurs tirets") return pgT("reason_many_dashes");
  if (fr === "Chiffres suspects dans le domaine") return pgT("reason_digits");
  if ((m = fr.match(/^Usurpation de sous-domaine : "(.+)"/))) return pgT("reason_subdomain_spoof", { brand: m[1] });
  if ((m = fr.match(/^Imitation probable de "(.+)"/))) return pgT("reason_brand_imitation", { brand: m[1] });
  if ((m = fr.match(/^Mot-clé suspect : "(.+)"/))) return pgT("reason_suspicious_keyword", { kw: m[1] });
  if ((m = fr.match(/^Extension de domaine suspecte : \.(.+)/))) return pgT("reason_suspicious_tld", { tld: m[1] });
  return fr;
}

function pgApplyTranslations(root) {
  (root || document).querySelectorAll("[data-i18n]").forEach(el => {
    el.innerHTML = pgT(el.dataset.i18n);
  });
  (root || document).querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    el.placeholder = pgT(el.dataset.i18nPlaceholder);
  });
}

function pgLoadLang(cb) {
  chrome.storage.local.get("pgLang", d => {
    PG_LANG = d.pgLang || (navigator.language || "fr").slice(0, 2);
    if (!PG_I18N[PG_LANG]) PG_LANG = "fr";
    cb && cb(PG_LANG);
  });
}

function pgSetLang(lang, cb) {
  if (!PG_I18N[lang]) lang = "fr";
  PG_LANG = lang;
  chrome.storage.local.set({ pgLang: lang }, () => cb && cb(lang));
}

// Écoute les changements de langue depuis le popup (synchronisation live)
if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.pgLang) {
      PG_LANG = changes.pgLang.newValue || "fr";
      if (!PG_I18N[PG_LANG]) PG_LANG = "fr";
    }
  });
}
